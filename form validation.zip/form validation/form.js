function signupform(){
    var fname = document.Uform.fname.value;
    var lname = document.Uform.lname.value;
    var email = document.Uform.email.value;
    var pass = document.Uform.pass.value;
    var repass = document.Uform.repass.value;

    //first name 
    if(fname == ""){
        document.getElementById("error").innerHTML=("write your first name");
        return false;
    }
    //last name
    if(lname == ""){
        document.getElementById("error").innerHTML=("please enter your last name");
        return false;
    }
    //Email validation

    if(email == ""){
        document.getElementById("error").innerHTML=("Please enter your email");
        return false;
    }
    if(email.indexOf("@", 0) < 0){
        document.getElementById("error").innerHTML=("Please enter '@ ");
        return false;
    }
    if(email.indexOf("gmail.", 0) < 0){
        document.getElementById("error").innerHTML=("Please enter 'gmail. ");
        return false;
    }
    //password validation
    if(pass == ""){
        document.getElementById("error").innerHTML=("please enter your password");
        return false;
    }
    if(repass == ""){
        document.getElementById("error").innerHTML=("please enter password again");
        return false;
    }
    if(repass != pass ){
        document.getElementById("error").innerHTML=("password not match");
        return false;
    }


}